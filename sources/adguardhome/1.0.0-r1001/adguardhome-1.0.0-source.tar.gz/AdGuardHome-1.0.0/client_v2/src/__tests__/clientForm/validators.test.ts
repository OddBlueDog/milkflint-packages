import { describe, expect, it } from 'vitest';
import {
    validateIdentifier,
    validateUpstreams,
    validateRequiredValue,
    validateIpv4,
    validateMac,
    validatePort,
    validateInstallPort,
    validatePlainDns,
    validateIpForGatewaySubnetMask,
    validateIpv4InCidr,
    validatePasswordLength,
    hasPasswordMinLength,
    validateIpNotDuplicate,
    validateIpPerLine,
    validateBetween,
    validateMinValue,
    validateCacheSize,
    validateRewriteNotExists,
    validateRewriteNotSame,
    validateLeaseTime,
} from 'panel/helpers/validators';

import { copy } from 'panel/__tests__/helpers/copy';

describe('validateIdentifier', () => {
    it('returns required error for empty string', () => {
        const result = validateIdentifier('', [], 0);
        expect(result).toBeTruthy();
    });

    it('returns required error for whitespace-only string', () => {
        const result = validateIdentifier('   ', [], 0);
        expect(result).toBeTruthy();
    });

    it('returns undefined for valid IPv4', () => {
        const result = validateIdentifier('192.168.1.1', ['192.168.1.1'], 0);
        expect(result).toBeUndefined();
    });

    it('returns undefined for valid IPv6', () => {
        const result = validateIdentifier('::1', ['::1'], 0);
        expect(result).toBeUndefined();
    });

    it('returns undefined for valid MAC', () => {
        const result = validateIdentifier('aa:bb:cc:dd:ee:ff', ['aa:bb:cc:dd:ee:ff'], 0);
        expect(result).toBeUndefined();
    });

    it('returns undefined for valid CIDR', () => {
        const result = validateIdentifier('192.168.1.0/24', ['192.168.1.0/24'], 0);
        expect(result).toBeUndefined();
    });

    it('returns undefined for valid IPv6 CIDR', () => {
        expect(validateIdentifier('2001:db8::/64', [], 0)).toBeUndefined();
    });

    // REGRESSION: GH #8610 — mixed-notation ranges were rejected by the retired
    // R_CIDR_IPV6, which matched the hex form only.
    it('returns undefined for IPv6 CIDR with an embedded IPv4 address', () => {
        expect(validateIdentifier('::ffff:192.168.1.0/120', [], 0)).toBeUndefined();
        expect(validateIdentifier('::ffff:c0a8:100/120', [], 0)).toBeUndefined();
    });

    it('returns format error for IPv6 CIDR with an out-of-range embedded IPv4 octet', () => {
        expect(validateIdentifier('::ffff:192.168.1.256/120', [], 0)).toBe(
            copy('clients_identifier_format_error'),
        );
    });

    // REGRESSION: netip.ParseAddr rejects IPv4 addresses with leading-zero
    // octets, so the backend answers 400 for identifiers the form accepted.
    it('returns format error for non-canonical IPv4 addresses with leading zeros', () => {
        expect(validateIdentifier('192.168.01.1', [], 0)).toBeTruthy();
        expect(validateIdentifier('010.0.0.1', [], 0)).toBeTruthy();
        expect(validateIdentifier('192.168.001.1', [], 0)).toBeTruthy();
    });

    it('returns format error for an IPv6 address with a non-canonical embedded IPv4 tail', () => {
        expect(validateIdentifier('::ffff:192.168.01.1', [], 0)).toBeTruthy();
        expect(validateIdentifier('::ffff:192.168.1.1', [], 0)).toBeUndefined();
    });

    // REGRESSION: netip.ParseAddr takes everything after the first `%` as the
    // zone ID, so the server parses this value as an address, not as a CIDR.
    it('returns undefined for an IPv6 address with a zone ID', () => {
        expect(validateIdentifier('fe80::1%eth0', [], 0)).toBeUndefined();
        expect(validateIdentifier('fe80::1%eth0/64', [], 0)).toBeUndefined();
        expect(validateIdentifier('2001:db8::1%eth0', [], 0)).toBeUndefined();
    });

    it('returns format error for an IPv6 address with an empty zone ID', () => {
        expect(validateIdentifier('fe80::1%', [], 0)).toBe(copy('clients_identifier_format_error'));
    });

    // Same outer-rune rule as the backend's ValidateHostnameLabel.
    it('returns format error for client IDs with leading or trailing hyphens', () => {
        expect(validateIdentifier('-abc', [], 0)).toBeTruthy();
        expect(validateIdentifier('abc-', [], 0)).toBeTruthy();
        expect(validateIdentifier('-', [], 0)).toBeTruthy();
        expect(validateIdentifier('a-b', [], 0)).toBeUndefined();
    });

    // Same net.ParseMAC rules as the backend.
    it('returns format error for MAC spellings the server refuses', () => {
        expect(validateIdentifier('aaaa:bb:cc:dd:ee:ff', [], 0)).toBeTruthy();
        expect(validateIdentifier('aa:bb-cc:dd:ee:ff', [], 0)).toBeTruthy();
        expect(validateIdentifier('aaaaa.bbbbb.cccc', [], 0)).toBeTruthy();
        expect(validateIdentifier('aa:bb:cc:dd:ee:ff', [], 0)).toBeUndefined();
        expect(
            validateIdentifier(
                '00:00:00:00:fe:80:00:00:00:00:00:00:02:00:5e:10:00:00:00:01',
                [],
                0,
            ),
        ).toBeUndefined();
    });

    it('returns undefined for valid ClientID', () => {
        const result = validateIdentifier('my-client-01', ['my-client-01'], 0);
        expect(result).toBeUndefined();
    });

    it('returns format error for invalid identifier', () => {
        const result = validateIdentifier('not a valid id!!!', [], 0);
        expect(result).toBeTruthy();
    });

    it('returns duplicate error for repeated identifier', () => {
        const result = validateIdentifier('test-id', ['other-id', 'test-id'], 0);
        expect(result).toBeTruthy();
    });

    it('returns undefined for unique identifiers', () => {
        const result = validateIdentifier('test-id', ['other-id', 'another-id'], 0);
        expect(result).toBeUndefined();
    });
});

describe('validateUpstreams', () => {
    it('returns undefined for an empty value', () => {
        const result = validateUpstreams('');
        expect(result).toBeUndefined();
    });

    it('returns undefined for comment lines', () => {
        const result = validateUpstreams('# this is a comment');
        expect(result).toBeUndefined();
    });

    it('returns undefined for blank lines', () => {
        const result = validateUpstreams('\n\n');
        expect(result).toBeUndefined();
    });

    it('returns undefined for a plain IP address', () => {
        const result = validateUpstreams('1.1.1.1');
        expect(result).toBeUndefined();
    });

    it('returns undefined for an IP with port', () => {
        const result = validateUpstreams('1.1.1.1:53');
        expect(result).toBeUndefined();
    });

    it('returns undefined for a protocol URL', () => {
        const result = validateUpstreams('tls://dns.example.com');
        expect(result).toBeUndefined();
    });

    it('returns undefined for a hostname', () => {
        const result = validateUpstreams('dns.example.com');
        expect(result).toBeUndefined();
    });

    it('returns error for a line without dot or colon', () => {
        const result = validateUpstreams('not-a-valid-upstream');
        expect(result).toBe(copy('form_error_format'));
    });

    it('returns error on the correct line number for mixed content', () => {
        const result = validateUpstreams('1.1.1.1\nbadline\ntls://ok.com');
        expect(result).toBe(copy('form_error_format_line', { line: 2 }));
    });

    it('skips comments and only flags real lines', () => {
        const result = validateUpstreams('# comment\nbadline\n1.1.1.1');
        expect(result).toBe(copy('form_error_format_line', { line: 2 }));
    });

    it('returns "Invalid format" for single invalid line with trailing newline', () => {
        const result = validateUpstreams('badline\n');
        expect(result).toBe(copy('form_error_format'));
    });

    it('returns "Invalid format" for single invalid line with leading newline', () => {
        const result = validateUpstreams('\nbadline');
        expect(result).toBe(copy('form_error_format'));
    });

    it('returns "Invalid format on lines 1, 2" when both invalid', () => {
        const result = validateUpstreams('bad1\nbad2');
        expect(result).toBe(copy('form_error_format_lines', { lines: '1, 2' }));
    });

    it('returns "Invalid format on line 2" when second line invalid in multi-content', () => {
        const result = validateUpstreams('1.1.1.1\nbad');
        expect(result).toBe(copy('form_error_format_line', { line: 2 }));
    });

    it('handles blank line between two invalid lines', () => {
        const result = validateUpstreams('bad1\n\nbad2');
        expect(result).toBe(copy('form_error_format_lines', { lines: '1, 3' }));
    });

    it('returns "Invalid format" for comment-then-invalid (one content line)', () => {
        const result = validateUpstreams('# comment\nbadline');
        expect(result).toBe(copy('form_error_format'));
    });

    it('returns "Invalid format" for invalid-then-comment (one content line)', () => {
        const result = validateUpstreams('badline\n# comment');
        expect(result).toBe(copy('form_error_format'));
    });
});

describe('validateRequiredValue', () => {
    it('returns undefined for non-empty string', () => {
        expect(validateRequiredValue('hello')).toBeUndefined();
    });

    it('returns error for empty string', () => {
        expect(validateRequiredValue('')).toBeTruthy();
    });

    it('returns error for whitespace-only string', () => {
        expect(validateRequiredValue('   ')).toBeTruthy();
    });

    it('returns undefined for 0 (zero is valid)', () => {
        expect(validateRequiredValue(0)).toBeUndefined();
    });

    it('returns error for undefined', () => {
        expect(validateRequiredValue(undefined)).toBeTruthy();
    });

    it('returns undefined for truthy number', () => {
        expect(validateRequiredValue(42)).toBeUndefined();
    });

    it('returns error for false', () => {
        expect(validateRequiredValue(false)).toBeTruthy();
    });
});

describe('validateIpv4', () => {
    it('returns undefined for valid IPv4', () => {
        expect(validateIpv4('192.168.1.1')).toBeUndefined();
    });

    it('returns error for invalid IPv4', () => {
        expect(validateIpv4('999.999.999.999')).toBeTruthy();
    });

    it('returns error for non-canonical IPv4 addresses with leading zeros', () => {
        expect(validateIpv4('192.168.01.1')).toBeTruthy();
        expect(validateIpv4('010.0.0.1')).toBeTruthy();
        expect(validateIpv4('192.168.1.01')).toBeTruthy();
    });

    it('returns undefined for empty string (skip)', () => {
        expect(validateIpv4('')).toBeUndefined();
    });

    it('returns undefined for undefined (skip)', () => {
        expect(validateIpv4(undefined)).toBeUndefined();
    });
});

describe('validateMac', () => {
    it('accepts the formats the server parses', () => {
        expect(validateMac('aa:bb:cc:dd:ee:ff')).toBeUndefined();
        expect(validateMac('AA:BB:CC:DD:EE:FF')).toBeUndefined();
        expect(validateMac('aabb.ccdd.eeff')).toBeUndefined();
    });

    // REGRESSION: net.ParseMAC also accepts 20-octet InfiniBand link-layer
    // addresses, which the six- and eight-octet forms did not cover.
    it('accepts 20-octet InfiniBand addresses', () => {
        expect(
            validateMac('00:00:00:00:fe:80:00:00:00:00:00:00:02:00:5e:10:00:00:00:01'),
        ).toBeUndefined();
        expect(validateMac('0000.0000.fe80.0000.0000.0000.0200.5e10.0000.0001')).toBeUndefined();
    });

    it('rejects over-long fields and mixed separators', () => {
        expect(validateMac('aaaa:bb:cc:dd:ee:ff')).toBeTruthy();
        expect(validateMac('aa:bb-cc:dd:ee:ff')).toBeTruthy();
        expect(validateMac('aaaaa.bbbbb.cccc')).toBeTruthy();
    });
});

describe('validatePort', () => {
    it('returns undefined for port in web range', () => {
        expect(validatePort(8080)).toBeUndefined();
    });

    it('returns undefined for boundary 0 (disabled)', () => {
        expect(validatePort(0)).toBeUndefined();
    });

    it('returns undefined for boundary 1', () => {
        expect(validatePort(1)).toBeUndefined();
    });

    it('returns undefined for boundary 80', () => {
        expect(validatePort(80)).toBeUndefined();
    });

    it('returns undefined for boundary 65535', () => {
        expect(validatePort(65535)).toBeUndefined();
    });

    it('returns error for port above 65535', () => {
        expect(validatePort(65536)).toBeTruthy();
    });

    it('returns error for negative port', () => {
        expect(validatePort(-1)).toBeTruthy();
    });

    it('returns undefined for undefined (no value)', () => {
        expect(validatePort(undefined)).toBeUndefined();
    });
});

describe('validateInstallPort', () => {
    it('returns undefined for valid port', () => {
        expect(validateInstallPort(80)).toBeUndefined();
    });

    it('returns undefined for boundary 1', () => {
        expect(validateInstallPort(1)).toBeUndefined();
    });

    it('returns undefined for boundary 65535', () => {
        expect(validateInstallPort(65535)).toBeUndefined();
    });

    it('returns error for 0 (install requires real port)', () => {
        expect(validateInstallPort(0)).toBeTruthy();
    });

    it('returns error for port above 65535', () => {
        expect(validateInstallPort(65536)).toBeTruthy();
    });
});

describe('validatePlainDns', () => {
    it('returns undefined when both encryption and plain DNS are on', () => {
        expect(validatePlainDns(true, { enabled: true })).toBeUndefined();
    });

    it('returns undefined when plain DNS is on, encryption off', () => {
        expect(validatePlainDns(true, { enabled: false })).toBeUndefined();
    });

    it('returns undefined when encryption is on, plain DNS off', () => {
        expect(validatePlainDns(false, { enabled: true })).toBeUndefined();
    });

    it('returns error when both are off', () => {
        expect(validatePlainDns(false, { enabled: false })).toBeTruthy();
    });
});

describe('validateIpForGatewaySubnetMask', () => {
    const validContext = {
        v4: { gateway_ip: '192.168.1.1', subnet_mask: '255.255.255.0' },
    };

    it('returns undefined for IP in subnet', () => {
        expect(validateIpForGatewaySubnetMask('192.168.1.5', validContext)).toBeUndefined();
    });

    it('returns error for IP outside subnet', () => {
        expect(validateIpForGatewaySubnetMask('10.0.0.1', validContext)).toBeTruthy();
    });

    it('returns undefined when context is missing', () => {
        expect(validateIpForGatewaySubnetMask('192.168.1.5', {})).toBeUndefined();
    });

    it('returns undefined for empty value', () => {
        expect(validateIpForGatewaySubnetMask('', validContext)).toBeUndefined();
    });

    // REGRESSION: guard must use nested allValues.v4.gateway_ip, not flat
    it('validates IP using nested context only (no flat keys)', () => {
        const nestedOnly = {
            v4: { gateway_ip: '192.168.1.1', subnet_mask: '255.255.255.0' },
        };
        // IP outside subnet should return error even without flat keys
        expect(validateIpForGatewaySubnetMask('10.0.0.1', nestedOnly)).toBeTruthy();
    });
});

describe('validateIpv4InCidr', () => {
    it('returns undefined for IP within CIDR', () => {
        expect(validateIpv4InCidr('192.168.1.5', { cidr: '192.168.1.0/24' })).toBeUndefined();
    });

    it('returns error for IP outside CIDR', () => {
        expect(validateIpv4InCidr('10.0.0.1', { cidr: '192.168.1.0/24' })).toBeTruthy();
    });
});

describe('validatePasswordLength', () => {
    it('returns "too_short" for a password shorter than 8 code points', () => {
        expect(validatePasswordLength('short')).toBe('too_short');
    });

    it('returns undefined for a valid password', () => {
        expect(validatePasswordLength('longenough')).toBeUndefined();
    });

    it('returns undefined for empty string (skipped)', () => {
        expect(validatePasswordLength('')).toBeUndefined();
    });

    it('returns undefined for undefined (skipped)', () => {
        expect(validatePasswordLength(undefined)).toBeUndefined();
    });

    it('returns "too_long" for a password longer than 72 UTF-8 bytes', () => {
        expect(validatePasswordLength('a'.repeat(73))).toBe('too_long');
    });

    it('counts code points for the minimum, like the backend', () => {
        // 5 code points but 14 UTF-8 bytes: the backend rejects it.
        expect(validatePasswordLength('aA🔒🔒🔒')).toBe('too_short');
        // 8 code points and 21 UTF-8 bytes.
        expect(validatePasswordLength('Grün🔑🔒🔑🔒')).toBeUndefined();
        // 'é' is one code point but two UTF-8 bytes.
        expect(validatePasswordLength('é'.repeat(7))).toBe('too_short');
        expect(validatePasswordLength('é'.repeat(8))).toBeUndefined();
    });

    it('counts UTF-8 bytes for the maximum, like bcrypt', () => {
        // 24 code points but 84 UTF-8 bytes.
        expect(validatePasswordLength(`Aa1!${'🔑'.repeat(20)}`)).toBe('too_long');
    });
});

describe('hasPasswordMinLength', () => {
    it('counts code points, not UTF-16 code units', () => {
        expect(hasPasswordMinLength('short')).toBe(false);
        // 8 UTF-16 code units but 5 code points.
        expect(hasPasswordMinLength('aA🔒🔒🔒')).toBe(false);
        expect(hasPasswordMinLength('longenough')).toBe(true);
    });
});

describe('validateIpNotDuplicate', () => {
    const leases = [{ ip: '192.168.1.10' }, { ip: '192.168.1.20' }];

    it('returns undefined for unique IP', () => {
        expect(validateIpNotDuplicate(leases)('192.168.1.30')).toBeUndefined();
    });

    it('returns error for duplicate IP', () => {
        expect(validateIpNotDuplicate(leases)('192.168.1.10')).toBeTruthy();
    });

    it('ignores the edit IP (editing existing lease)', () => {
        expect(validateIpNotDuplicate(leases, '192.168.1.10')('192.168.1.10')).toBeUndefined();
    });

    it('returns undefined for empty leases', () => {
        expect(validateIpNotDuplicate([])('192.168.1.1')).toBeUndefined();
    });

    it('returns undefined for empty value', () => {
        expect(validateIpNotDuplicate(leases)('')).toBeUndefined();
    });
});

describe('validateIpPerLine', () => {
    it('returns undefined for valid multi-line IPs', () => {
        expect(validateIpPerLine('192.168.1.1\n10.0.0.1')).toBeUndefined();
    });

    it('returns error when a line is invalid', () => {
        expect(validateIpPerLine('192.168.1.1\nnot-an-ip')).toBeTruthy();
    });

    it('returns undefined for empty string', () => {
        expect(validateIpPerLine('')).toBeUndefined();
    });

    it('skips blank lines', () => {
        expect(validateIpPerLine('\n\n')).toBeUndefined();
    });

    it('skips blank lines between valid IPs', () => {
        expect(validateIpPerLine('192.168.1.1\n\n10.0.0.1')).toBeUndefined();
    });
});

describe('numeric range validators', () => {
    it('validateBetween returns error when value is out of range', () => {
        expect(validateBetween(-1, 0, 32)).toBeTruthy();
        expect(validateBetween(33, 0, 32)).toBeTruthy();
        expect(validateBetween(0, 0, 32)).toBeUndefined();
        expect(validateBetween(32, 0, 32)).toBeUndefined();
        expect(validateBetween(16, 0, 32)).toBeUndefined();
    });

    it('validateBetween returns error for non-finite values', () => {
        expect(validateBetween(NaN, 0, 32)).toBeTruthy();
        expect(validateBetween(Infinity, 0, 32)).toBeTruthy();
        expect(validateBetween(-Infinity, 0, 32)).toBeTruthy();
    });

    it('validateBetween optionally rejects non-integer values', () => {
        expect(validateBetween(0.5, 0, 32, { integer: true })).toBeTruthy();
        expect(validateBetween(0.5, 0, 32)).toBeUndefined();
        expect(validateBetween(16, 0, 32, { integer: true })).toBeUndefined();
    });

    it('validateMinValue returns error when value is below min', () => {
        expect(validateMinValue(0, 1)).toBeTruthy();
        expect(validateMinValue(1, 1)).toBeUndefined();
        expect(validateMinValue(10, 1)).toBeUndefined();
    });
});

describe('validateCacheSize', () => {
    it('returns undefined when cache is disabled', () => {
        expect(validateCacheSize(0, false)).toBeUndefined();
        expect(validateCacheSize(999999999999, false)).toBeUndefined();
    });

    it('returns error for 0 when enabled', () => {
        const result = validateCacheSize(0, true);
        expect(result).toBeTruthy();
    });

    it('returns error for empty string when enabled', () => {
        const result = validateCacheSize('', true);
        expect(result).toBeTruthy();
    });

    it('returns undefined for a valid size when enabled', () => {
        expect(validateCacheSize(1000, true)).toBeUndefined();
    });

    it('validates a numeric string when enabled', () => {
        expect(validateCacheSize('1000', true)).toBeUndefined();
    });

    it('returns error for value exceeding UINT32_MAX', () => {
        const result = validateCacheSize(4294967296, true);
        expect(result).toBeTruthy();
    });

    it('returns error for a fractional size when enabled', () => {
        expect(validateCacheSize(1.5, true)).toBeTruthy();
    });

    it('returns undefined at UINT32_MAX boundary', () => {
        expect(validateCacheSize(4294967295, true)).toBeUndefined();
    });
});

describe('validateRewriteNotExists', () => {
    it('returns undefined for a non-existing domain', () => {
        const result = validateRewriteNotExists('new.example.com', '1.2.3.4', [
            { domain: 'existing.example.com', answer: '1.2.3.4' },
        ]);
        expect(result).toBeUndefined();
    });

    it('returns undefined for the same domain with a different answer', () => {
        const result = validateRewriteNotExists('example.com', '5.6.7.8', [
            { domain: 'example.com', answer: '1.2.3.4' },
        ]);
        expect(result).toBeUndefined();
    });

    it('returns error for a duplicated domain and answer', () => {
        const result = validateRewriteNotExists('example.com', '1.2.3.4', [
            { domain: 'example.com', answer: '1.2.3.4' },
        ]);
        expect(result).toBeTruthy();
    });

    it('returns undefined when editing the same rewrite', () => {
        const result = validateRewriteNotExists(
            'example.com',
            '1.2.3.4',
            [{ domain: 'example.com', answer: '1.2.3.4' }],
            { domain: 'example.com', answer: '1.2.3.4' },
        );
        expect(result).toBeUndefined();
    });

    it('returns undefined when editing and changing the answer', () => {
        const result = validateRewriteNotExists(
            'example.com',
            '5.6.7.8',
            [{ domain: 'example.com', answer: '1.2.3.4' }],
            { domain: 'example.com', answer: '1.2.3.4' },
        );
        expect(result).toBeUndefined();
    });

    it('returns error when editing and changing to an existing domain/answer pair', () => {
        const result = validateRewriteNotExists(
            'other.example.com',
            '1.2.3.4',
            [
                { domain: 'example.com', answer: '1.2.3.4' },
                { domain: 'other.example.com', answer: '1.2.3.4' },
            ],
            { domain: 'example.com', answer: '1.2.3.4' },
        );
        expect(result).toBeTruthy();
    });

    it('returns undefined for an empty domain', () => {
        const result = validateRewriteNotExists('', '1.2.3.4', [
            { domain: 'example.com', answer: '1.2.3.4' },
        ]);
        expect(result).toBeUndefined();
    });

    it('returns undefined for an empty answer', () => {
        const result = validateRewriteNotExists('example.com', '', [
            { domain: 'example.com', answer: '1.2.3.4' },
        ]);
        expect(result).toBeUndefined();
    });

    it('case-insensitive duplicate check', () => {
        const result = validateRewriteNotExists('Example.COM', '1.2.3.4', [
            { domain: 'example.com', answer: '1.2.3.4' },
        ]);
        expect(result).toBeTruthy();
    });
});

describe('validateRewriteNotSame', () => {
    it('returns undefined when domain and answer differ', () => {
        const result = validateRewriteNotSame('example.com', '192.168.1.1');
        expect(result).toBeUndefined();
    });

    it('returns error when domain equals answer', () => {
        const result = validateRewriteNotSame('example.com', 'example.com');
        expect(result).toBeTruthy();
    });

    it('returns error case-insensitively', () => {
        const result = validateRewriteNotSame('Example.COM', 'example.com');
        expect(result).toBeTruthy();
    });

    it('returns undefined for empty values', () => {
        expect(validateRewriteNotSame('', 'example.com')).toBeUndefined();
        expect(validateRewriteNotSame('example.com', '')).toBeUndefined();
        expect(validateRewriteNotSame('', '')).toBeUndefined();
    });
});

describe('validateUpstreams with bang prefix', () => {
    it('rejects lines starting with ! as invalid upstreams', () => {
        expect(validateUpstreams('! comment line\n8.8.8.8')).toBeTruthy();
    });

    it('rejects only ! lines as invalid', () => {
        expect(validateUpstreams('! first\n! second')).toBeTruthy();
    });

    it('rejects !-prefixed URLs that would otherwise pass address check', () => {
        expect(validateUpstreams('! https://dns10.quad9.net/dns-query')).toBeTruthy();
    });

    it('rejects !-prefixed upstream with dot in comment', () => {
        expect(validateUpstreams('! dns.example.com:53')).toBeTruthy();
    });

    it('still accepts # comments', () => {
        expect(validateUpstreams('# comment\n8.8.8.8')).toBeUndefined();
    });

    it('rejects ! and invalid non-comment lines', () => {
        expect(validateUpstreams('! good\ninvalidline')).toBeTruthy();
    });
});

describe('validateLeaseTime', () => {
    it('accepts 1 (minimum)', () => {
        expect(validateLeaseTime(1)).toBeUndefined();
    });

    it('rejects 0', () => {
        expect(validateLeaseTime(0)).toBeTruthy();
    });

    it('accepts UINT32_MAX (4294967295)', () => {
        expect(validateLeaseTime(4294967295)).toBeUndefined();
    });

    it('rejects UINT32_MAX + 1 (4294967296)', () => {
        expect(validateLeaseTime(4294967296)).toBeTruthy();
    });

    it('rejects empty string', () => {
        expect(validateLeaseTime('')).toBeTruthy();
    });

    it('rejects undefined', () => {
        expect(validateLeaseTime(undefined)).toBeTruthy();
    });

    it('rejects NaN', () => {
        expect(validateLeaseTime(NaN)).toBeTruthy();
    });
});
